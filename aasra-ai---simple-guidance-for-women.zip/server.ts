import express from 'express';
import path from 'path';
import dotenv from 'dotenv';
import { GoogleGenAI, Type } from '@google/genai';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;
const isProd = process.env.NODE_ENV === 'production';

app.use(express.json());

// Initialize server-side Gemini client
const apiKey = process.env.GEMINI_API_KEY || '';
const ai = apiKey
  ? new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    })
  : null;

// Fallback search in verified database if API key is absent or quota limit hit
const FALLBACK_KNOWLEDGE = [
  {
    keywords: ['மகளிர் உரிமை', 'magalir', '1000', 'urimai', 'monthly', 'women scheme', 'tamil nadu 1000', 'kmut'],
    data: {
      simpleAnswer: "கலைஞர் மகளிர் உரிமைத் திட்டம் மூலம் தகுதியுள்ள குடும்பத் தலைவிகளுக்கு மாதம் தோறும் ரூ.1,000 உரிமைத் தொகை வங்கி கணக்கில் நேரடியாக வழங்கப்படுகிறது.",
      targetBeneficiary: "குடும்பத்தில் குடும்பத் தலைவியாக உள்ள 21 வயது பூர்த்தியடைந்த பெண்கள்.",
      eligibilityDetails: "ஆண்டு குடும்ப வருமானம் ரூ.2.5 லட்சத்திற்குள் இருக்க வேண்டும். குடும்பத்தில் அரசு ஊழியர்கள், வருமான வரி செலுத்துபவர்கள் இருக்கக்கூடாது.",
      requiredDocuments: [
        "ஆதார் அட்டை (Aadhaar Card)",
        "ஸ்மார்ட் குடும்ப அட்டை (Smart Ration Card)",
        "ஆதாருடன் இணைக்கப்பட்ட வங்கிக் கணக்கு புத்தகம் (Bank Passbook)",
        "மின்சார கட்டண ரசீது அல்லது நுகர்வோர் எண்"
      ],
      stepByStepGuide: [
        "1. ரேஷன் கடை அல்லது கிராம முகாமில் விண்ணப்பப் படிவத்தைப் பெறவும்.",
        "2. உங்கள் ஆதார் மற்றும் வங்கி கணக்கு விவரங்களைப் பூர்த்தி செய்யவும்.",
        "3. இ-சேவை மையம் அல்லது சிறப்பு முகாமில் பயோமெட்ரிக் பதிவு செய்து படிவத்தை சமர்ப்பிக்கவும்.",
        "4. ஒப்புகைச் சீட்டை (Acknowledgement slip) பத்திரமாக வைத்திருக்கவும்."
      ],
      officialPortal: {
        name: "தமிழ்நாடு மகளிர் உரிமைத் திட்டம் போர்டல்",
        url: "https://kmut.tn.gov.in",
        officeType: "அருகிலுள்ள இ-சேவை மையம் அல்லது தாலுகா அலுவலகம்"
      },
      verificationNotice: "முக்கிய குறிப்பு: தகுதி விவரங்களை உங்கள் கிராம நிர்வாக அலுவலர் (VAO) அல்லது இ-சேவை மையத்தில் உறுதிப்படுத்திக் கொள்ளவும்.",
      spokenScript: "கலைஞர் மகளிர் உரிமைத் திட்டம் மூலம் தகுதியுள்ள பெண்களுக்கு மாதம் ஆயிரம் ரூபாய் வழங்கப்படுகிறது. ஆதார் அட்டை, ரேஷன் அட்டை மற்றும் வங்கி கணக்கு புத்தகத்துடன் உங்கள் அருகிலுள்ள இ-சேவை முகாமில் விண்ணப்பிக்கலாம்."
    }
  },
  {
    keywords: ['தையல்', 'sewing', 'machine', 'tailor', 'தையல் இயந்திரம்', 'free machine', 'skill', 'கற்றல்'],
    data: {
      simpleAnswer: "பொருளாதாரத்தில் பின்தங்கிய பெண்கள், விதவைகள் மற்றும் ஆதரவற்ற மகளிர் தையல் தொழில் மூலம் வருமானம் ஈட்ட இலவச தையல் இயந்திரம் மற்றும் பயிற்சி அரசு வழங்குகிறது.",
      targetBeneficiary: "20 முதல் 40 வயதுக்குட்பட்ட ஏழைப் பெண்கள், விதவைகள், கணவரால் கைவிடப்பட்ட மகளிர்.",
      eligibilityDetails: "குடும்ப ஆண்டு வருமானம் ரூ.72,000க்குள் இருக்க வேண்டும். தையல் பயிற்சி முடித்ததற்கான சான்றிதழ் அவசியம்.",
      requiredDocuments: [
        "ஆதார் அட்டை",
        "வருமானச் சான்றிதழ் (Tahsildar / VAO)",
        "வயதுச் சான்றிதழ் (Age Proof)",
        "தையல் பயிற்சி முடித்த சான்றிதழ் (Tailoring certificate)",
        "விதவை அல்லது கணவரால் கைவிடப்பட்டதற்கான சான்று (பொருந்துமாயின்)"
      ],
      stepByStepGuide: [
        "1. மாவட்ட சமூக நல அலுவலகம் அல்லது வட்டார வளர்ச்சி அலுவலகத்தில் (BDO) விண்ணப்பத்தைப் பெறவும்.",
        "2. விண்ணப்பத்தை பூர்த்தி செய்து ஆவண நகல்களை இணைக்கவும்.",
        "3. ஊராட்சி ஒன்றிய சமூக நல அலுவலரிடம் சமர்ப்பிக்கவும்.",
        "4. நேரடி ஆய்வுக்குப் பின் மாவட்ட ஆட்சியர் அலுவலகம் மூலம் இயந்திரம் வழங்கப்படும்."
      ],
      officialPortal: {
        name: "தமிழ்நாடு சமூக நலத்துறை",
        url: "https://www.tn.gov.in",
        officeType: "மாவட்ட சமூக நல அலுவலகம் அல்லது வட்டார வளர்ச்சி அலுவலகம் (BDO)"
      },
      verificationNotice: "ஆண்டுதோறும் ஒதுக்கப்படும் எண்ணிக்கைக்கு ஏற்ப முன்னுரிமை வழங்கப்படும். வட்டார வளர்ச்சி அலுவலகத்தில் உறுதிப்படுத்தவும்.",
      spokenScript: "பெண்கள் சுயதொழில் தொடங்க அரசு இலவச தையல் இயந்திரம் வழங்குகிறது. ஆறு மாத தையல் பயிற்சி சான்றிதழ், ஆதார் அட்டை மற்றும் வருமான சான்றிதழ் எடுத்துக்கொண்டு உங்கள் வட்டார வளர்ச்சி அலுவலகத்தில் விண்ணப்பிக்கலாம்."
    }
  },
  {
    keywords: ['ரேஷன்', 'ration', 'card', 'ரேசன்', 'குடும்ப அட்டை', 'service', 'சேவை'],
    data: {
      simpleAnswer: "ஸ்மார்ட் ரேஷன் கார்டு மூலம் குடும்பத்திற்கான மலிவு விலை உணவு தானியங்களைப் பெறலாம் மற்றும் அரசின் அனைத்து நலத்திட்டங்களுக்கும் முக்கிய அடையாள ஆவணமாக இதைப் பயன்படுத்தலாம்.",
      targetBeneficiary: "திருமணமான புதிய குடும்பங்கள் அல்லது தனித்தனி சமையல் அமைத்துக் கொண்ட குடும்பங்கள்.",
      eligibilityDetails: "பெற்றோரின் ரேஷன் கார்டிலிருந்து பெயர் நீக்கப்பட்டதற்கான நீக்கல் சான்றிதழ் இருக்க வேண்டும்.",
      requiredDocuments: [
        "அனைத்து குடும்ப உறுப்பினர்களின் ஆதார் அட்டைகள்",
        "முகவரி சான்று (மின்சார ரசீது அல்லது வீட்டு வரி ரசீது)",
        "திருமணப் பத்திரிகை அல்லது பதிவுச் சான்றிதழ்",
        "பழைய ரேஷன் அட்டையில் பெயர் நீக்கிய ரசீது (Surrender Certificate)",
        "குடும்பத் தலைவியின் புகைப்படம்"
      ],
      stepByStepGuide: [
        "1. ஆவணங்களுடன் அருகிலுள்ள இ-சேவை மையத்திற்கு செல்லவும்.",
        "2. TNPDS போர்ட்டலில் 'புதிய ஸ்மார்ட் கார்டு' விண்ணப்பிக்கவும்.",
        "3. சேவை கட்டணம் செலுத்தி ஒப்புகைச் சீட்டு பெறவும்.",
        "4. வட்ட வழங்கல் அலுவலர் (TSO) ஆய்வு செய்த பின்னர் அட்டை விநியோகிக்கப்படும்."
      ],
      officialPortal: {
        name: "தமிழ்நாடு பொது விநியோகத் திட்டம் (TNPDS)",
        url: "https://www.tnpds.gov.in",
        officeType: "அருகிலுள்ள இ-சேவை மையம் அல்லது தாலுகா வழங்கல் அலுவலகம்"
      },
      verificationNotice: "விண்ணப்ப நிலையை tnpds.gov.in இணையதளத்தில் உங்கள் குறிப்பு எண்ணைப் பயன்படுத்தி சரிபார்க்கலாம்.",
      spokenScript: "புதிய ரேஷன் கார்டு பெற அனைத்து குடும்பத்தினரின் ஆதார் அட்டை, மின் கட்டண ரசீது, திருமண பத்திரிகை மற்றும் பெயர் நீக்கிய சான்றிதழுடன் இ-சேவை மையத்தில் விண்ணப்பிக்கவும்."
    }
  }
];

function findFallbackAnswer(query: string, language: string) {
  const qLower = query.toLowerCase();
  for (const item of FALLBACK_KNOWLEDGE) {
    if (item.keywords.some(k => qLower.includes(k))) {
      return item.data;
    }
  }
  // Generic fallback if no specific match
  if (language === 'en') {
    return {
      simpleAnswer: "Government welfare schemes and services are available through your local e-Sevai or CSC centre, helping women with financial support, skill training, and essential documents.",
      targetBeneficiary: "Women citizens, especially from rural and economically weaker backgrounds.",
      eligibilityDetails: "Varies by specific scheme (usually requires valid residence, age proof, and income certificate).",
      requiredDocuments: [
        "Aadhaar Card",
        "Smart Family Ration Card",
        "Bank Passbook (Aadhaar linked)",
        "Income and Community Certificate (from Tahsildar / e-Sevai)"
      ],
      stepByStepGuide: [
        "1. Visit your nearest Village Panchayat Office or Government e-Sevai / CSC centre.",
        "2. Inquire with the operator about relevant women empowerment and welfare programs.",
        "3. Submit required photocopies with original verification.",
        "4. Collect and safely store your computer-generated application acknowledgement receipt."
      ],
      officialPortal: {
        name: "National Portal of India / myScheme",
        url: "https://www.myscheme.gov.in",
        officeType: "Local e-Sevai / CSC Centre or Gram Panchayat Office"
      },
      verificationNotice: "Always verify criteria and required documents in person at your local e-Sevai centre before applying.",
      spokenScript: "You can access women's government schemes and skill training through your nearest e-Sevai centre or Panchayat office. Keep your Aadhaar card, ration card, and bank passbook ready."
    };
  }

  return {
    simpleAnswer: "பெண்களுக்கான அரசு நலத்திட்டங்கள் மற்றும் சேவைகளை உங்கள் அருகிலுள்ள இ-சேவை மையம் அல்லது கிராம பஞ்சாயத்து அலுவலகம் மூலம் எளிதாகப் பெறலாம்.",
    targetBeneficiary: "கிராமப்புற மற்றும் எளிய பின்னணி கொண்ட பெண்கள்.",
    eligibilityDetails: "திட்டத்தைப் பொறுத்து தகுதி மாறும் (பொதுவாக ஆதார், இருப்பிடச் சான்று மற்றும் வருமான சான்று தேவைப்படும்).",
    requiredDocuments: [
      "ஆதார் அட்டை (Aadhaar Card)",
      "ஸ்மார்ட் ரேஷன் கார்டு (Ration Card)",
      "வங்கி கணக்கு புத்தகம் (Bank Passbook)",
      "வருமானம் மற்றும் சாதிச் சான்றிதழ்"
    ],
    stepByStepGuide: [
      "1. உங்கள் அருகிலுள்ள இ-சேவை மையம் அல்லது கிராம நிர்வாக அலுவலகத்திற்குச் செல்லவும்.",
      "2. அங்குள்ள பணியாளரிடம் நீங்கள் விரும்பும் திட்டம் குறித்து கேட்கவும்.",
      "3. ஆவண நகல்களைச் சமர்ப்பித்து விண்ணப்பிக்கவும்.",
      "4. விண்ணப்ப பதிவு ஒப்புகைச் சீட்டைப் பத்திரமாகப் பெற்றுக்கொள்ளவும்."
    ],
    officialPortal: {
      name: "இந்திய அரசு நலத்திட்ட தளம் / myScheme",
      url: "https://www.myscheme.gov.in",
      officeType: "அருகிலுள்ள இ-சேவை மையம் அல்லது கிராம ஊராட்சி அலுவலகம்"
    },
    verificationNotice: "அனைத்து அரசு திட்ட தகவல்களையும் உங்கள் அருகிலுள்ள இ-சேவை மையம் அல்லது அரசு அலுவலகத்தில் உறுதிப்படுத்திக் கொள்ளவும்.",
    spokenScript: "பெண்களுக்கான அரசு நலத்திட்டங்கள் பற்றி தெரிந்துகொள்ள ஆதார் அட்டை, ரேஷன் அட்டை மற்றும் வங்கி புத்தகத்துடன் உங்கள் அருகிலுள்ள இ-சேவை மையத்தை அணுகலாம்."
  };
}

// API endpoint for Aasra AI assistant
app.post('/api/ask-aasra', async (req, res) => {
  try {
    const { question, language = 'ta', category } = req.body;

    if (!question || typeof question !== 'string' || !question.trim()) {
      res.status(400).json({ error: 'Question is required' });
      return;
    }

    const trimmedQuestion = question.trim();

    // If Gemini client is not initialized, use curated knowledge fallback
    if (!ai) {
      console.warn('GEMINI_API_KEY is not configured. Utilizing verified knowledge base.');
      const fallback = findFallbackAnswer(trimmedQuestion, language);
      res.json({ ...fallback, isOfflineFallback: true });
      return;
    }

    const languageInstruction =
      language === 'ta'
        ? 'Tamil (தமிழ்) in simple, warm, everyday conversational language that an uneducated rural woman can immediately understand.'
        : language === 'hi'
        ? 'Hindi (हिंदी) in simple, accessible, respectful everyday spoken language.'
        : language === 'te'
        ? 'Telugu (తెలుగు) in simple, clear, everyday spoken language.'
        : 'English in extremely simple, plain, jargon-free everyday English (short sentences, 5th-grade reading level).';

    const systemInstruction = `You are "Aasra AI" (ஆஸ்ரா), an ultra-reliable, deeply compassionate, and simple voice-and-text guide for women in rural and underserved areas.
Many users have zero digital experience, no English knowledge, and no someone to guide them.

CRITICAL INSTRUCTIONS & ACCURACY RULES:
1. Provide guidance in ${languageInstruction}.
2. DO NOT invent government schemes, eligibility requirements, documents, deadlines, or website URLs.
3. Ground your answer in real, established Indian schemes (Central or State schemes like Kalaignar Magalir Urimai Thittam, Pudhumai Penn, Moovalur Ramamirtham, Pradhan Mantri Matru Vandana Yojana, PM Vishwakarma, Free Sewing Machine / Tailoring Schemes, PM Ujjwala Yojana, Lakhpati Didi, SHG Mudra Loans, e-Sevai smart ration cards, community certificates, voter ID).
4. If a detail varies by district or year, clearly state that it should be verified with the official staff at the nearest e-Sevai / CSC centre or Panchayat office.
5. Provide a clear, natural "spokenScript" in the same language designed specifically for Text-To-Speech audio playback, written warmly, without asterisks or bullet formatting so it sounds like a caring elder sister or community worker speaking aloud.
6. The response must follow the strict JSON schema provided.`;

    const prompt = `User's question: "${trimmedQuestion}"
Selected category context: "${category || 'General'}"
Preferred response language: "${language}"

Please analyze the user's question and provide a complete, clear, step-by-step response according to the required schema. Keep language simple, encouraging, and accurate.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        systemInstruction,
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            simpleAnswer: {
              type: Type.STRING,
              description: 'A 2-3 sentence simple, compassionate answer explaining what this is in everyday words.',
            },
            targetBeneficiary: {
              type: Type.STRING,
              description: 'Who is eligible or who this scheme/service is meant for.',
            },
            eligibilityDetails: {
              type: Type.STRING,
              description: 'Key eligibility criteria (age, income limit, family conditions).',
            },
            requiredDocuments: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: 'List of necessary documents (e.g. Aadhaar, Ration card, Passbook).',
            },
            stepByStepGuide: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: 'Clear, numbered step-by-step instructions on where to go and how to apply.',
            },
            officialPortal: {
              type: Type.OBJECT,
              properties: {
                name: { type: Type.STRING, description: 'Official government scheme/service name' },
                url: { type: Type.STRING, description: 'Official website URL (or null if in-person)' },
                officeType: { type: Type.STRING, description: 'Nearest in-person office to visit (e.g. e-Sevai, CSC, BDO office)' }
              },
              required: ['name', 'officeType']
            },
            verificationNotice: {
              type: Type.STRING,
              description: 'Friendly reminder to verify details at the local e-Sevai/CSC or official portal.'
            },
            spokenScript: {
              type: Type.STRING,
              description: 'Smooth spoken script in the response language without markdown or special symbols for browser Text-To-Speech.'
            }
          },
          required: [
            'simpleAnswer',
            'targetBeneficiary',
            'eligibilityDetails',
            'requiredDocuments',
            'stepByStepGuide',
            'officialPortal',
            'verificationNotice',
            'spokenScript'
          ]
        }
      }
    });

    const responseText = response.text;
    if (!responseText) {
      throw new Error('Empty response from model');
    }

    const parsedData = JSON.parse(responseText);
    res.json(parsedData);
  } catch (error: any) {
    console.error('Error handling /api/ask-aasra:', error);
    // Return curated fallback on failure so the user never sees a broken screen
    const { question = '', language = 'ta' } = req.body || {};
    const fallback = findFallbackAnswer(question, language);
    res.json({
      ...fallback,
      isOfflineFallback: true,
      notice: 'Served through verified knowledge base'
    });
  }
});

// Setup Vite middleware in dev or static files in prod
async function startServer() {
  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, () => {
    console.log(`Aasra AI server listening on port ${PORT} (prod=${isProd})`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
